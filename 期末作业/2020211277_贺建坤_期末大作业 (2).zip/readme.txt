请修改路径文件以运行

将predict_mo.ipynb与模型.pth文件放在同一个文件下
创建一个文件夹为待测试文件图片将文件放进去或者修改ipynb文件路径部分代码
后会输出到同一文件夹下的pred_YANSHOU.csv文件中

源文件为
predict_2 copy.ipynb
下面的文件是调用模型文件的代码
predict_mo.ipynb
模型文件为
model_weights.pth

